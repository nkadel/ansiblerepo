#pythran export np0(float [])
import numpy as np
def np0(a):
    return 1. / a + a
