#ifndef PYTHONIC_FUNCTOOLS_REDUCE_HPP
#define PYTHONIC_FUNCTOOLS_REDUCE_HPP

#include "pythonic/include/functools/reduce.hpp"
#include "pythonic/builtins/reduce.hpp"

#endif
