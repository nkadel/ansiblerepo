#ifndef PYTHONIC_BUILTIN_NONE_HPP
#define PYTHONIC_BUILTIN_NONE_HPP

#include "pythonic/include/builtins/None.hpp"

#endif
