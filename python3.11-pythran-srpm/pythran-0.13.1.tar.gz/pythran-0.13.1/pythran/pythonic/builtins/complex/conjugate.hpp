#ifndef PYTHONIC_BUILTIN_COMPLEX_CONJUGATE_HPP
#define PYTHONIC_BUILTIN_COMPLEX_CONJUGATE_HPP

#include "pythonic/include/builtins/complex/conjugate.hpp"
#include "pythonic/numpy/conjugate.hpp"

#endif
