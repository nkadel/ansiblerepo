#ifndef PYTHONIC_BUILTIN_ABS_HPP
#define PYTHONIC_BUILTIN_ABS_HPP

#include "pythonic/include/builtins/abs.hpp"
#include "pythonic/numpy/abs.hpp"

#endif
