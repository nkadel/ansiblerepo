#ifndef PYTHONIC_BUILTIN_SET_CLEAR_HPP
#define PYTHONIC_BUILTIN_SET_CLEAR_HPP

#include "pythonic/include/builtins/set/clear.hpp"
#include "pythonic/__dispatch__/clear.hpp"

#endif
