#ifndef PYTHONIC_SET_UPDATE_HPP
#define PYTHONIC_SET_UPDATE_HPP

#include "pythonic/include/builtins/set/update.hpp"
#include "pythonic/__dispatch__/update.hpp"

#endif
