#ifndef PYTHONIC_BUILTIN_GETATTR_HPP
#define PYTHONIC_BUILTIN_GETATTR_HPP

#include "pythonic/include/builtins/getattr.hpp"

#endif
