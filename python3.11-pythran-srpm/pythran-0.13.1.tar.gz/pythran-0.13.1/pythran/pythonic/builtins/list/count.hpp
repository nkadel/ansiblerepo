#ifndef PYTHONIC_BUILTIN_LIST_COUNT_HPP
#define PYTHONIC_BUILTIN_LIST_COUNT_HPP

#include "pythonic/include/builtins/list/count.hpp"
#include "pythonic/__dispatch__/count.hpp"

#endif
