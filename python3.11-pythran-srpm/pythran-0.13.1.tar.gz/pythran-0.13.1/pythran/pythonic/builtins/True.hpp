#ifndef PYTHONIC_BUILTIN_TRUE_HPP
#define PYTHONIC_BUILTIN_TRUE_HPP

#include "pythonic/include/builtins/True.hpp"

#endif
