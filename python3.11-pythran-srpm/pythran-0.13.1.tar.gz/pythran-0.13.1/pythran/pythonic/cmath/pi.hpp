#ifndef PYTHONIC_CMATH_PI_HPP
#define PYTHONIC_CMATH_PI_HPP

#include "pythonic/include/cmath/pi.hpp"

#endif
